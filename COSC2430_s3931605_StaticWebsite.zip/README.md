# COSC2430_StaticWebsite

Hi, This is for my uni project only.
Welcome my CV online website
Here are 5 pages: index.html is the homepage to nav to other page as well as the page where github host the website.
cv.html will be about my cv.
projects.html will be about all my projects recently.
contactme.html will show how you send me your contact.
blog.html will show my blogs recently.

URL to my online website: https://anhminhbo.github.io/COSC2430_StaticWebsite/
